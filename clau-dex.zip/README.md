# clau-dex

A clean-room, Codex-native, local-first bootstrap repository.

## Mission
Define and bootstrap a local-first, CLI-first engineering system centered on:
- Codex-native workflows
- prompt and agent assets stored in-repo
- repository analysis and execution discipline
- phased architecture planning before runtime implementation

## Status
Bootstrap phase. The repository currently contains documentation, prompt and agent folders,
local Codex configuration, a local CLI shell script with a narrow bootstrap audit command,
one minimal GitHub Actions workflow that validates the current shell surface, and no dependency
graph or formal test harness.

## Current Layout
- `docs/`: charter, roadmap, architecture notes, and phased plans
- `agents/`: agent role definitions and starting prompts
- `prompts/`: reusable prompt packs and execution prompts
- `scripts/`: local bootstrap helpers, including the first CLI shell entry script and bootstrap audit command
- `src/`: implementation code when implementation begins
- `.codex/config.toml`: project-scoped Codex defaults

## Local Shell Surface
The PowerShell shell in `scripts/clau-dex.ps1` remains a bootstrap-stage repository helper.
Its current command surface includes local status inspection, narrow bootstrap auditing, repo
asset listing, operating-rule summaries, and focused agent scaffolding.

## Bootstrap Validation
The repository includes one minimal GitHub Actions workflow that runs the current PowerShell
shell validation surface on `push` and `pull_request`:
- `./scripts/clau-dex.ps1 help`
- `./scripts/clau-dex.ps1 status`
- `./scripts/clau-dex.ps1 audit`

## Working Rules
- Treat the checked-in repository as the source of truth.
- Keep the project clean-room and avoid implying unimplemented capabilities.
- Prefer Markdown, plain text, and local scripts over external services.
- Add runtime code only after the architecture and workflow docs call for it.
